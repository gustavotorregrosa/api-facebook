<?php
 session_start();
require_once __DIR__ . '/vendor/autoload.php'; // change path as neededs


$fb = new \Facebook\Facebook([
  'app_id' => '773612373002528',
  'app_secret' => '968386905cbfb4f2f3c1c6d3912045f9',
  'default_graph_version' => 'v2.2',
  //'default_access_token' => '{access-token}', // optional
]);

$helper = $fb->getRedirectLoginHelper();


$permissions = ['email']; // Optional permissions
$loginUrl = $helper->getLoginUrl('http://localhost/login-facebook2/fb-callback.php', $permissions);

echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';